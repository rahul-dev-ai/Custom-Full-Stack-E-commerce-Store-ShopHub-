# ShopHub – Custom E-commerce Store

A modern, fully responsive e-commerce demo built with **Next.js 16**, **TypeScript**, and **Tailwind CSS**.

Perfect for showcasing on Upwork as a full-stack / frontend portfolio project.

## Features

- **Product Catalog** – Browse, search, filter by category, and sort
- **Product Detail Pages** – Images, ratings, stock status, quantity selector
- **Shopping Cart** – Add / remove / update quantities (persisted in localStorage)
- **Checkout Flow** – Contact, shipping, and mock payment form
- **Admin Dashboard** – Stats cards + product inventory table
- **Responsive Design** – Looks great on mobile, tablet, and desktop
- **Modern UI** – Clean emerald theme, smooth hover effects, professional layout

## Tech Stack

- Next.js 16 (App Router)
- TypeScript
- Tailwind CSS v4
- React Context + localStorage for cart state
- Unsplash images for products

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Project Structure

```
src/
├── app/
│   ├── page.tsx              # Home (Hero + Featured)
│   ├── products/
│   │   ├── page.tsx          # Product listing + filters
│   │   └── [id]/page.tsx     # Product detail
│   ├── cart/page.tsx         # Shopping cart
│   ├── checkout/page.tsx     # Checkout + mock payment
│   └── admin/page.tsx        # Admin dashboard
├── components/
│   ├── Header.tsx
│   ├── Footer.tsx
│   └── ProductCard.tsx
├── context/
│   └── CartContext.tsx       # Cart state management
└── data/
    └── products.ts           # Product data
```

## Demo Notes

- Cart data is saved in the browser’s localStorage
- Payment is completely simulated (no real charges)
- Admin panel is frontend-only (no real backend/auth)
- All product images are from Unsplash

## For Upwork Portfolio

1. Deploy to Vercel (free): `npx vercel`
2. Take screenshots of Home, Products, Cart, Checkout, and Admin
3. Add the live demo link + this GitHub repo to your Upwork portfolio entry

---

Built as a portfolio project for Rahul G. – Full-stack App & Web Developer

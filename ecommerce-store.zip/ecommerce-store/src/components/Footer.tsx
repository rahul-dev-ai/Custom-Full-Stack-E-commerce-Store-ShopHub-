export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-emerald-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">S</span>
              </div>
              <span className="text-xl font-bold text-white">ShopHub</span>
            </div>
            <p className="text-gray-400 max-w-md">
              A modern full-stack e-commerce platform built with Next.js. 
              Showcasing custom product catalog, cart, checkout, and admin dashboard.
            </p>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Shop</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/products" className="hover:text-emerald-400 transition">All Products</a></li>
              <li><a href="/products?category=Electronics" className="hover:text-emerald-400 transition">Electronics</a></li>
              <li><a href="/products?category=Clothing" className="hover:text-emerald-400 transition">Clothing</a></li>
              <li><a href="/products?category=Home" className="hover:text-emerald-400 transition">Home</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Demo</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/cart" className="hover:text-emerald-400 transition">Cart</a></li>
              <li><a href="/checkout" className="hover:text-emerald-400 transition">Checkout</a></li>
              <li><a href="/admin" className="hover:text-emerald-400 transition">Admin Panel</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500">
            © 2026 ShopHub Demo • Built for Upwork Portfolio
          </p>
          <p className="text-sm text-gray-500">
            Next.js • TypeScript • Tailwind CSS
          </p>
        </div>
      </div>
    </footer>
  );
}

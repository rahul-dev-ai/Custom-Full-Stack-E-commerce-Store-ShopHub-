export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  stock: number;
  rating: number;
  featured?: boolean;
}

export const products: Product[] = [
  {
    id: 1,
    name: "Wireless Bluetooth Headphones",
    description: "Premium noise-cancelling over-ear headphones with 30-hour battery life and crystal clear sound quality. Perfect for work, travel, and music lovers.",
    price: 89.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&h=500&fit=crop",
    stock: 45,
    rating: 4.7,
    featured: true,
  },
  {
    id: 2,
    name: "Minimalist Leather Wallet",
    description: "Handcrafted genuine leather bifold wallet with RFID blocking technology. Slim design that holds up to 8 cards and cash.",
    price: 49.99,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=500&h=500&fit=crop",
    stock: 120,
    rating: 4.5,
    featured: true,
  },
  {
    id: 3,
    name: "Smart Fitness Watch",
    description: "Track your health with heart rate monitoring, sleep analysis, GPS, and 50+ workout modes. Water resistant up to 50m.",
    price: 149.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop",
    stock: 32,
    rating: 4.8,
    featured: true,
  },
  {
    id: 4,
    name: "Organic Cotton T-Shirt",
    description: "Ultra-soft 100% organic cotton t-shirt. Sustainable, breathable, and available in multiple colors. Fair trade certified.",
    price: 29.99,
    category: "Clothing",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop",
    stock: 200,
    rating: 4.4,
  },
  {
    id: 5,
    name: "Ceramic Pour-Over Coffee Set",
    description: "Complete pour-over coffee maker set with ceramic dripper, server, and filters. Elevate your morning coffee ritual.",
    price: 64.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=500&h=500&fit=crop",
    stock: 58,
    rating: 4.9,
    featured: true,
  },
  {
    id: 6,
    name: "Portable Power Bank 20000mAh",
    description: "High-capacity fast-charging power bank with dual USB ports and USB-C. Charges phones up to 5 times on a single charge.",
    price: 39.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=500&h=500&fit=crop",
    stock: 85,
    rating: 4.6,
  },
  {
    id: 7,
    name: "Yoga Mat Premium",
    description: "Extra-thick non-slip yoga mat with alignment lines. Eco-friendly TPE material, perfect for yoga, pilates, and floor exercises.",
    price: 34.99,
    category: "Sports",
    image: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=500&h=500&fit=crop",
    stock: 70,
    rating: 4.7,
  },
  {
    id: 8,
    name: "Stainless Steel Water Bottle",
    description: "Insulated 32oz water bottle keeps drinks cold for 24 hours or hot for 12 hours. BPA-free and leak-proof design.",
    price: 24.99,
    category: "Sports",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=500&h=500&fit=crop",
    stock: 150,
    rating: 4.5,
  },
  {
    id: 9,
    name: "Wireless Charging Pad",
    description: "Fast wireless charger compatible with all Qi-enabled devices. Sleek aluminum design with LED indicator.",
    price: 27.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=500&h=500&fit=crop",
    stock: 95,
    rating: 4.3,
  },
  {
    id: 10,
    name: "Canvas Tote Bag",
    description: "Durable heavy-duty canvas tote with reinforced handles. Perfect for shopping, beach, or everyday use. Machine washable.",
    price: 19.99,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=500&h=500&fit=crop",
    stock: 180,
    rating: 4.6,
  },
  {
    id: 11,
    name: "Mechanical Keyboard RGB",
    description: "Gaming mechanical keyboard with customizable RGB lighting, hot-swappable switches, and aluminum frame.",
    price: 119.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=500&h=500&fit=crop",
    stock: 40,
    rating: 4.8,
    featured: true,
  },
  {
    id: 12,
    name: "Aromatherapy Diffuser",
    description: "Ultrasonic essential oil diffuser with 7 LED colors, timer settings, and auto shut-off. Creates a calming atmosphere.",
    price: 32.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=500&h=500&fit=crop",
    stock: 65,
    rating: 4.4,
  },
];

export const categories = ["All", "Electronics", "Clothing", "Accessories", "Home", "Sports"];
